package com.grindrplus.persistence.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class HttpBodyLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val url: String,
    val method: String,
    val body: String,
    val request_body: String,
    val response_body: String,
    val device_info: String,
    val user_agent: String,
    val request_headers: String,
    val response_headers: String,
    val response_body_preview: String
)
