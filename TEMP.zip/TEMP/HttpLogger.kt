package com.grindrplus.core

import android.os.Environment
import com.grindrplus.GrindrPlus
import com.grindrplus.persistence.model.HttpLogEntity
import de.robv.android.xposed.XposedBridge
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object HttpLogger {
    private val logFile = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "GrindrPlus_HttpLogs.txt"
    )

    fun log(request: Request, response: Response) {
        try {
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

            val logMessage = """
                [$timestamp]
                ${request.method} ${request.url} -> ${response.code}
                Auth: ${request.header("Authorization")?.take(20)}...
                Device: ${request.header("L-Device-Info")}
                ${"=".repeat(50)}
                
            """.trimIndent()

            if (!logFile.exists()) {
                logFile.createNewFile()
                logFile.setReadable(true, true)
                logFile.setWritable(true, true)
            }

            // Simple file append - this should work if CredentialsLogger works
            logFile.appendText("$logMessage\n")

            // Also log to Xposed for immediate visibility
            XposedBridge.log("HTTP: ${request.method} ${request.url} -> ${response.code}")

        } catch (e: Exception) {
            XposedBridge.log("HttpLogger failed: ${e.message}")
        }
    }
}