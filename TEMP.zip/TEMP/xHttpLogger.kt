package com.grindrplus.core

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.os.Environment
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object HttpLogger {
    // External database file - same approach as CredentialsLogger
    private val dbFile = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "GrindrPlus_HttpLogs.db"
    )

    private fun getDatabase(): SQLiteDatabase {
        return SQLiteDatabase.openOrCreateDatabase(dbFile, null)
    }

    fun initialize() {
        val db = getDatabase()
        try {
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS http_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER NOT NULL,
                    method TEXT NOT NULL,
                    url TEXT NOT NULL,
                    status_code INTEGER,
                    auth_header TEXT,
                    device_info TEXT,
                    user_agent TEXT,
                    request_headers TEXT,
                    response_headers TEXT,
                    response_body_preview TEXT
                )
            """)
        } finally {
            db.close()
        }
    }

    fun log(request: Request, response: Response) {
        try {
            initialize() // Ensure table exists

            val db = getDatabase()
            val values = ContentValues().apply {
                put("timestamp", System.currentTimeMillis())
                put("method", request.method)
                put("url", request.url.toString())
                put("status_code", response.code)
                put("auth_header", request.header("Authorization")?.take(100)) // Truncate if needed
                put("device_info", request.header("l-device-info"))
                put("user_agent", request.header("User-Agent"))
                put("request_headers", formatHeaders(request.headers))
                put("response_headers", formatHeaders(response.headers))

                // Safe body preview - only first 2KB to avoid large data
                val bodyPreview = response.peekBody(2048).string()
                put("response_body_preview", bodyPreview.take(2000))
            }

            db.insert("http_logs", null, values)
            db.close()

        } catch (e: Exception) {
            Logger.e("HttpLogger database write failed: ${e.message}")
        }
    }

    private fun formatHeaders(headers: okhttp3.Headers): String {
        return headers.toMultimap().entries.joinToString("; ") { (key, values) ->
            "$key: ${values.joinToString(", ")}"
        }
    }

    // Bonus: Query methods for your commands!
    fun getRecentLogs(limit: Int = 100): List<Map<String, Any?>> {
        return try {
            val db = getDatabase()
            val logs = db.rawQuery(
                "SELECT * FROM http_logs ORDER BY timestamp DESC LIMIT $limit", null
            ).use { cursor ->
                val result = mutableListOf<Map<String, Any?>>()
                while (cursor.moveToNext()) {
                    val row = mutableMapOf<String, Any?>()
                    for (i in 0 until cursor.columnCount) {
                        row[cursor.getColumnName(i)] = when (cursor.getType(i)) {
                            android.database.Cursor.FIELD_TYPE_INTEGER -> cursor.getInt(i)
                            android.database.Cursor.FIELD_TYPE_FLOAT -> cursor.getFloat(i)
                            android.database.Cursor.FIELD_TYPE_STRING -> cursor.getString(i)
                            else -> cursor.getString(i)
                        }
                    }
                    result.add(row)
                }
                result
            }
            db.close()
            logs
        } catch (e: Exception) {
            emptyList()
        }
    }
}