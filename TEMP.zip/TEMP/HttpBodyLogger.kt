package com.grindrplus.core

import android.content.Context
import android.os.Environment
import com.grindrplus.GrindrPlus
import com.grindrplus.persistence.model.HttpBodyLogEntity
import de.robv.android.xposed.XposedBridge
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object HttpBodyLogger {
    private val logFile = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "GrindrPlus_HttpBodies.txt"
    )

    fun log(url: String, method: String, body: String?) {
        if (body.isNullOrEmpty() || !body.trim().startsWith("{")) {
            return
        }

        try {
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val logMessage = """
                [$timestamp] $method $url
                $body
                ${"=".repeat(80)}
                
            """.trimIndent()

            logFile.appendText("$logMessage\n")
            XposedBridge.log("BodyLogger: Logged ${body.length} chars for $url")

        } catch (e: Exception) {
            XposedBridge.log("BodyLogger failed: ${e.message}")
        }
    }
}
//
//    /**
//     * Copies the grindrplus.db file from internal app storage to the public Downloads folder.
//     * This makes the HTTP body logs accessible to the user.
//     * @return True if the export was successful, false otherwise.
//     */
//    fun exportLogsToDownloads(): Boolean {
//        return try {
//            val context = GrindrPlus.context
//            val sourceDb = context.getDatabasePath("grindrplus.db")
//            if (!sourceDb.exists()) {
//                Logger.w("exportLogsToDownloads: grindrplus.db not found.")
//                return false
//            }
//
//            val downloadsDir =
//                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
//            val destinationFile = File(downloadsDir, "HttpBodyLogs.db")
//
//            sourceDb.copyTo(destinationFile, overwrite = true)
//            Logger.i("Successfully exported grindrplus.db to ${destinationFile.absolutePath}")
//            true
//        } catch (e: IOException) {
//            Logger.e("Error exporting HTTP logs to Downloads: ${e.message}")
//            false
//        }
//    }
//}