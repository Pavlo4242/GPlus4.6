package com.grindrplus.persistence.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class HttpLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val method: String,
    val url: String,
    val requestHeaders: String,
    val responseCode: Int,
    val responseMessage: String,
    val responseHeaders: String
)